# importing necessary libraries and functions
import numpy as np
from flask import Flask, request, redirect, url_for, jsonify, render_template
import pickle
from flask import Flask, make_response, request
import io
from io import StringIO
import csv
import pandas as pd
import numpy as np
import pickle

app = Flask(__name__) #Initialize the flask App
def transform(text_file_contents):
    return text_file_contents.replace("=", ",")
    
model = pickle.load(open('modelOpt.pickle', 'rb')) # loading the trained model


#Home route:
@app.route('/') # Homepage
def home():
    return render_template('index.html')


#Predict route:
@app.route('/predict',methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    '''
    
    # retrieving values from form
    init_features = [float(x) for x in request.form.values()]
    final_features = [np.array(init_features)]

    prediction = model.predict(final_features) # making prediction


    return render_template('index.html', prediction_text='Predicted Class: {}'.format(prediction)) # rendering the predicted result


# #Upload File
# @app.route('/', methods=['POST'])
# def upload_file():
#     uploaded_file = request.files['file']
#     if uploaded_file.filename != '':
#         uploaded_file.save(uploaded_file.filename)
#     return redirect(url_for('index'))



@app.route('/transform', methods=["POST"])
def transform_view():
    f = request.files['file']
    if not f:
        return "No file"

    stream = io.StringIO(f.stream.read().decode("UTF8"), newline=None)
    csv_input = csv.reader(stream)
    #print("file contents: ", file_contents)
    #print(type(file_contents))
    print(csv_input)
    for row in csv_input:
        print(row)

    stream.seek(0)
    result = transform(stream.read())

    df = pd.read_csv(StringIO(result),usecols=['pkg_weight','pkg_length', 'pkg_width', 'pkg_height','origin','pkg_cube','gvwr','trailer_height','total_packages', 'avg_packages_per_day'])
    df.dropna(inplace=True)
    

    # load the model from disk
    
    loaded_model = pickle.load(open('modelOpt.pickle', 'rb'))
    df['prediction'] = loaded_model.predict(df)

    response = make_response(df.to_csv())
    response.headers["Content-Disposition"] = "attachment; filename=result.csv"
    return response

if __name__ == "__main__":
   app.debug = True
   app.run(host='0.0.0.0')